import SwiftUI

@main
struct TestIOSApp: App {
    var body: some Scene {
        WindowGroup {
            CarListView()
        }
    }
}
