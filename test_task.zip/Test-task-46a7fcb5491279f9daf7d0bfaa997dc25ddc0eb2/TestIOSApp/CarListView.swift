import SwiftUI

struct CarListView: View {
    var body: some View {
        /*
         Display the car data in the cell.
         - image on the left side
         - title,
         - description
         */
        Text("Here is a test view")
    }
}
/*
 Display the car details in a new view.
 This could be a CarDetailView that shows more information about the selected car.
 - Full size Image
 - title
 - description
 - productionDates
 - bodyStyles
 - engines
 - wheelbase
 */
