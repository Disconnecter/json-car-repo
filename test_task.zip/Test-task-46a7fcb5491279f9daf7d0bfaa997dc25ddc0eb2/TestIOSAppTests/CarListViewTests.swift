import XCTest
@testable import TestIOSApp

class CarListViewControllerTests: XCTestCase {

    var carListViewController: CarListView!

    override func setUp() {
        super.setUp()
    }

    func testWeAreShowingCarsInTableView() {
    }    
}
